-- ============================================================
-- Özel Test İstem Sistemi — Veritabanı Şeması (PostgreSQL)
-- Supabase ve on-prem Postgres'te BİREBİR çalışır (taşınabilir).
-- Enum yerine text + CHECK kullanıldı: ileride yeni değer eklemek kolay.
-- ============================================================

-- ------------------------------------------------------------
-- KULLANICILAR  (uzman / asistan / teknisyen)
-- ------------------------------------------------------------
create table kullanicilar (
  id          uuid primary key default gen_random_uuid(),
  ad_soyad    text not null,
  rol         text not null check (rol in ('uzman','asistan','teknisyen')),
  pin         text,                       -- hafif oturum için (4-6 hane)
  aktif       boolean not null default true,
  created_at  timestamptz not null default now()
);

-- ------------------------------------------------------------
-- TEST KATALOĞU  (gruplu açılır listelerin kaynağı)
-- ------------------------------------------------------------
create table test_katalog (
  id     uuid primary key default gen_random_uuid(),
  grup   text not null check (grup in ('ihk','hk','fish','kesit','molekuler','diger')),
  ad     text not null,                   -- ör. "ER", "PR", "CerbB2", "Ki67", "p63"
  sira   int  not null default 0,         -- listede gösterim sırası
  aktif  boolean not null default true
);

-- ------------------------------------------------------------
-- ŞABLONLAR  (kişiye özel, ör. "fd meme 1")
-- ------------------------------------------------------------
create table sablonlar (
  id         uuid primary key default gen_random_uuid(),
  sahip_id   uuid not null references kullanicilar(id),
  ad         text not null,               -- ör. "fd meme 1"
  created_at timestamptz not null default now()
);

create table sablon_kalemleri (
  id        uuid primary key default gen_random_uuid(),
  sablon_id uuid not null references sablonlar(id) on delete cascade,
  test_id   uuid references test_katalog(id),
  ozel_test text                          -- katalogda olmayan serbest test
);

-- ------------------------------------------------------------
-- İSTEMLER
-- ------------------------------------------------------------
create table istemler (
  id             uuid primary key default gen_random_uuid(),
  patoloji_no    text not null,
  istem_yapan_id uuid not null references kullanicilar(id),  -- girişi yapan kişi
  uzman_id       uuid references kullanicilar(id),           -- kimin adına
  acil           boolean not null default false,
  not_metni      text,
  durum          text not null default 'istendi'
                   check (durum in ('istendi','cihazda','tamamlandi','iptal')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

-- ------------------------------------------------------------
-- İSTEM KALEMLERİ  (blok + test; her satır bir blok-test eşleşmesi)
-- "Aynı seçimi birden fazla bloğa" = birden fazla satır.
-- Bu düz yapı, Excel yedeğine de tablo olarak birebir dökülür.
-- ------------------------------------------------------------
create table istem_kalemleri (
  id        uuid primary key default gen_random_uuid(),
  istem_id  uuid not null references istemler(id) on delete cascade,
  blok_no   text not null,
  test_id   uuid references test_katalog(id),
  ozel_test text                          -- "diğer" / serbest metin
  -- İleride kalem bazlı takip istenirse buraya: durum text eklenebilir.
);

-- ------------------------------------------------------------
-- DURUM GEÇMİŞİ  (kim, ne zaman, hangi duruma aldı — iz sürme)
-- ------------------------------------------------------------
create table istem_log (
  id            uuid primary key default gen_random_uuid(),
  istem_id      uuid not null references istemler(id) on delete cascade,
  eski_durum    text,
  yeni_durum    text not null,
  degistiren_id uuid references kullanicilar(id),
  created_at    timestamptz not null default now()
);

-- ------------------------------------------------------------
-- İNDEKSLER  (sık kullanılan sorgular için)
-- ------------------------------------------------------------
create index on istemler (durum);
create index on istemler (created_at desc);
create index on istem_kalemleri (istem_id);
create index on sablon_kalemleri (sablon_id);
create index on sablonlar (sahip_id);

-- ------------------------------------------------------------
-- Örnek katalog verisi (silinebilir / genişletilebilir)
-- ------------------------------------------------------------
insert into test_katalog (grup, ad, sira) values
  ('ihk','ER',10), ('ihk','PR',20), ('ihk','CerbB2',30),
  ('ihk','Ki67',40), ('ihk','p63',50), ('ihk','E-cadherin',60),
  ('fish','HER2 FISH',10),
  ('molekuler','ALK',10),
  ('kesit','Yeni kesit (H&E)',10);
